package com.nicolas.chatapp.exception;

public class MessageException extends Exception{

    public MessageException(String message) {
        super(message);
    }

}
